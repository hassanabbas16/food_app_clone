# react-native-food-delivery-app
Youtube link for the tutorial
https://youtu.be/IDVOCjOPaGc
