import { createContext } from "react";


export const RestaurantContext = createContext(null)