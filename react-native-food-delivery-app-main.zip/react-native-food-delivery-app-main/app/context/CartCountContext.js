import { createContext } from "react";


export const CartCountContext = createContext(null)