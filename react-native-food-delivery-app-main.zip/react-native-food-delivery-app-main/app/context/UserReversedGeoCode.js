import { createContext } from "react";


export const UserReversedGeoCode = createContext(null)